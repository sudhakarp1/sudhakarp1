'''
	Sample XML to Start with
'''

from dicttoxml import dicttoxml 
from xml.dom.minidom import parseString

student = { '1':{
        'name' : 'Jack',
        'class' : {
            'std': 'Fifth',
             'sec': 'B'
        },
        'school': 'Delhi Public School',
    },
    '2':{
        'name' : 'John',
        'class' : {
            'std': 'Fifth',
             'sec': 'B'
        },
        'school': 'Delhi Public School',
        },
    '3':{
    
        'name' : 'Tom',
        'class' : {
            'std': 'Fifth',
             'sec': 'B'
        },
        'school': 'Delhi Public School',
    },
    '4':{
        'name' : 'Mike',
        'class' : {
            'std': 'Fifth',
             'sec': 'B'
        },
        'school': 'Delhi Public School',
    }
}


print(student)

resXml = dicttoxml(student)

print(resXml)

resDom = parseString(resXml)

print('*' * 50)
print(resDom.toprettyxml())
with open('students.xml','w') as f:
    f.write(resDom.toprettyxml())
    


