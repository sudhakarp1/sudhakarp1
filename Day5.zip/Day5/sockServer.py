'''
'''

import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #1
soc.bind(('192.168.1.5',9999)) #2
soc.listen(5)#2

#for i in range(5):
while True
    conn, addr = soc.accept() #4
    try :
        #from_client = b''
        while True:
            data = conn.recv(20)
            if not data: 
                break
            print(data)
            conn.send(b'Hai this is from Server')
    except:
        pass        
    finally:
        conn.close() #5
        print(f'client {addr} disconnected')
    