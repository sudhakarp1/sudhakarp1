import unittest
import testMathFunctionOne as tmf

class testClass(unittest.TestCase):
	@classmethod    
	def setUpClass(cls):
		print('setUpClass')

	@classmethod    
	def tearDownClass(cls):
		print('Tear Down Class')
        
	def setUp(self):
		print('setUp...')
    
	def tearDown(self):
		print('tearDown...\n')

	def test_add(self):
    
		print('test_add')
		self.assertEqual(tmf.add(110,3),113)
		self.assertEqual(tmf.add(-1,1),0)
		self.assertEqual(tmf.add(-1,-1),-2)
	
	def test_subtract(self):
		print('test_subtract')
		self.assertEqual(tmf.subtract(110,3),107)
		self.assertEqual(tmf.subtract(-1,1),-2)
		self.assertEqual(tmf.subtract(-1,-1),0)
	
	def test_divide(self):
		print('test_divide')
		self.assertEqual(tmf.divide(10,3),3)
		self.assertEqual(tmf.divide(9,3),3)
		self.assertEqual(tmf.divide(-1,1),-1)
		self.assertRaises(ValueError,tmf.divide,10,0)
	
if __name__== '__main__':
	unittest.main()
	
