'''
	Sample XML to Start with
'''

import xml.dom.minidom 

domObj = xml.dom.minidom.parse('students.xml')

print(domObj.nodeName)
print(domObj.firstChild)
print(domObj.firstChild.tagName)
print('*' * 40)
classInfo = domObj.getElementsByTagName('n')
print(f'classInfo--> {classInfo}')
for i in classInfo:
    name = i.getElementsByTagName('name')[0]
    print(name.firstChild.data)
    school = i.getElementsByTagName('school')[0]
    print(school.firstChild.data)



