'''
	Simple parsing of XML file using xml.sax
'''
import xml.sax

class studentParse(xml.sax.ContentHandler):
    def __init__(self):
        #print('Init method called')
        self.currentData = ''
        self.info = ''
        self.name=''
        self.clas=''
        self.school=''

    def startElement(self, tag, attributes):
        #print('Start Element')
        self.currentData = tag
        if tag=='n':
            print('********Student Info*********')
            n = attributes['info']
            print(f'Info {n}')
        
    def endElement(self,tag):
        if self.currentData == 'name':
            print(f'Name: {self.name}')         
        elif self.currentData == 'class':
            print(f'Class: {self.clas}')         

        elif self.currentData == 'school':
            print(f'School: {self.school}')         


        self.currentData=''

    #parse through the whole xml doc
    def characters(self,content):
        if self.currentData == 'name':
            self.name=content  
       
        elif self.currentData == 'class':
            self.clas = content
       
        elif self.currentData == 'school':
            self.school=content
       

if __name__ =='__main__': 
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_namespaces,0)

    Handler = studentParse()
    parser.setContentHandler(Handler)

    parser.parse('students.xml')

