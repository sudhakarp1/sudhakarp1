import socket

hst = socket.gethostname()
print(f'My System name is : {hst}')
print(f'My System name is : {socket.gethostbyname(hst)}')