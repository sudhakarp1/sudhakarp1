'''
A Simple UDP Sever
'''
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(('192.168.1.5',9999))
print('Server is up and Running...')

while True:
    msg, address = s.recvfrom(25)
    print(f'Message {msg} from  {address}')

    s.sendto(b'Hai this is from Server...\n',address)