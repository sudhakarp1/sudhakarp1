'''
UDP Client..
'''


import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto(b'Hi Says my Client...',('192.168.1.5',9999))

msg, address = s.recvfrom(1024)
print(f'Message {msg} from  {address}')
