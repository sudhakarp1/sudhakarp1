def add(x, y):
	''' Adding Two Numbers'''
	return x + y
	
def subtract(x, y):
	''' Subtracting Two Numbers'''
	return x - y

def multiply(x, y):
	''' multiplying Two Numbers'''
	return x * y

def divide(x, y):
	''' dividing Two Numbers'''
	if y==0:
		raise ValueError('Cannot divide by Zero')
	return x // y
	