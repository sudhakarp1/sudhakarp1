'''
'''

import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

soc.connect((('192.168.1.5',9999)))

try:
	soc.send(b'Hai is this client..')
	Len = 0
	msgLen = 5
	for i in range(10): 
		data = soc.recv(25)
		msgLen=len(data)
		print(data.decode('utf-8'))
		soc.send(b'Hai is this client..')        

finally:
    soc.close()