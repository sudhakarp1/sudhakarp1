'''
	simple producer/Consumer Problem using Queue	
'''
import concurrent.futures
import queue
import random
import threading
import time 

def producer(queue, event):
    while not event.is_set():
        message = 'message :' + str(random.randint(1,101))
        print(f'Producer Produced... {message}')
        queue.put(message)
        
        print('Producer received Event...')
        
def consumer(queue,event):
    while not event.is_set() or not queue.empty():
        print(f'Consumer Consumed ...{queue.get()}')
    
    print('Consumer Recieved Event...')
    
    
channel = queue.Queue(maxsize=5) # buffer size
event = threading.Event()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    executor.submit(producer,channel,event)
    executor.submit(consumer,channel,event)

    time.sleep(0.1)
    event.set()