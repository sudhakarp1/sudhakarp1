import queue

class Job:
    def __init__(self,priority, descr):
        self.priority = priority
        self.descr = descr
        print('New Job: ',descr)
        
    def __lt__(self,other):
        return self.priority < other.priority
    
que = queue.PriorityQueue()

que.put(Job(3,'Avg Lev Job'))
que.put(Job(10,'Low Lev Job'))
que.put(Job(0,'Highest Lev Job'))
que.put(Job(18,'Least Lev Job'))
que.put(Job(15,'lower Lev Job'))
que.put(Job(2,'high Lev Job'))

while not que.empty():
    job = que.get()
    print(f'Processing {job.priority}: ',job.descr)
