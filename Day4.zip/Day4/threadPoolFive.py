'''
	Inheriting the Thread Class
'''
import concurrent.futures
import time

def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    return f'Work {secs} Completed..Fun Continues'

start = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor() as executor:
    lstTimes = [4,3,2,1,3]    
    results = executor.map(funAtWork,lstTimes)     
    for i in results:
        print(i)
    
end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')