'''
	Inheriting the Thread Class
'''
import concurrent.futures
import time

def funAtWork():
    print(f'Work Started it will take 1 seconds')
    time.sleep(1)
    return f'Work Completed..Fun Continues'

start = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor() as executor:
    t1 = executor.submit(funAtWork)
    t2 = executor.submit(funAtWork)
    
    print(t1.result())
    print(t2.result())

end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')