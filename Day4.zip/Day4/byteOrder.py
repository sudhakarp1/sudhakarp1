'''
	demo on byte Order
'''

import sys
import socket
print(f'Byte Order here : {sys.byteorder}')
val = 0x1234
print(f'val: {val} \t\tval in Hexa {hex(val)}')
val=socket.htons(val)
print(f'val: {val} \t\tval in Hexa {hex(val)}')