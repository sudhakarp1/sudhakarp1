import time
import threading

def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    print(f'Work {secs} Completed..Fun Continues')
    
start = time.perf_counter()

t1 = threading.Thread(target=funAtWork,args=(1,))
t2 = threading.Thread(target=funAtWork,args=(2,))

t1.start()
t2.start()
print(threading.currentThread())#return current thread object info
print(threading.enumerate()) #prints list of all thread objects currently active
print(threading.activeCount())#total count of active threads

end = time.perf_counter()

t1.join()
t2.join()

print(f'program finished in {round(end-start,3)} seconds')