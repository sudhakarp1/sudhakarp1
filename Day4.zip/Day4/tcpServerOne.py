'''
'''

import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #1
soc.bind(('192.168.1.4',9999)) #2
soc.listen(5)#2
for i in range(5):
    conn, addr = soc.accept() #4
    from_client = b''
    while True:
        data = conn.recv(20)
        if not data: 
            break
            
        from_client+=data
        print(from_client.decode('utf-8'))
        conn.send(b'Hai this is from Server')
    conn.close() #5
    print(f'client {addr} disconnected')
    