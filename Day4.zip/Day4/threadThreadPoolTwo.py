'''
	Inheriting the Thread Class
'''
import concurrent.futures
import time

def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    return f'Work {secs} Completed..Fun Continues'

start = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor() as executor:
    t1 = executor.submit(funAtWork,2)
    t2 = executor.submit(funAtWork,3)
    
    print(t1.result())
    print(t2.result())

end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')