'''
	Inheriting the Thread Class
'''

from threading import Thread
import time

class MyThread(Thread):
    def __init__(self, name):
        Thread.__init__(self)
        self.name = name
        
    def run(self): #called when you make a call to start method  
        print('Starting ',self.name)
        funAtWork()        
            

def funAtWork():
    print(f'Work Started it will take 1 seconds')
    time.sleep(1)
    print(f'Work Completed..Fun Continues')


start = time.perf_counter()

t1 = MyThread('My Thread #1')
t2 = MyThread('My Thread #2')

t1.start()
t2.start()

t1.join()
t2.join()

end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')