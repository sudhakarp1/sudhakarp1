'''
	Inheriting the Thread Class
'''
import concurrent.futures
import time

def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    return f'Work {secs} Completed..Fun Continues'

start = time.perf_counter()

with concurrent.futures.ThreadPoolExecutor() as executor:
    lstTimes = [4,3,2,1,3]
    
    lst = [executor.submit(funAtWork,lstTimes[i]) for i in range(5)]
    
    for i in concurrent.futures.as_completed(lst):
        print(i.result())
    
    
end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')