import queue

que = queue.LifoQueue() # LifoQueue
for i in range(5):
    que.put('hello '+ str(i))
    
    
while not que.empty():
    print(que.get())