'''
	Intro to Threads
'''
import time
import threading

def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    print(f'Work {secs} Completed..Fun Continues')
    
start = time.perf_counter()

threadIDs = []
myTimers = [4,2,3,1,4]
for i in myTimers:
    t = threading.Thread(target=funAtWork,args=[i])
    t.start()
    threadIDs.append(t)
    
for thread in threadIDs:
    thread.join()

end = time.perf_counter()

print(f'program finished in {round(end-start,3)} seconds')