'''
	Inheriting the Thread Class
'''
from threading import Thread
import time

class MyThread(Thread):
    def __init__(self, name, *args, **kwargs):
        Thread.__init__(self)
        self.name = name
        self.target = kwargs['target']
        self.args = kwargs['args']
        
    def run(self): #called when you make a call to start method  
        print('Starting ',self.name)
        self.target(*self.args)        
            
def funAtWork(secs):
    print(f'Work Started it will take {secs} seconds')
    time.sleep(secs)
    print(f'Work {secs} Completed..Fun Continues')

start = time.perf_counter()

t1 = MyThread('My Thread #1',target=funAtWork,args=(1,))
t2 = MyThread('My Thread #2',target=funAtWork,args=(2,))

t1.start()
t2.start()

t1.join()
t2.join()

end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')