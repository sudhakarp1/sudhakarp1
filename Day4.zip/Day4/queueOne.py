import queue


que = queue.Queue() # FIFO
for i in range(5):
    que.put('hello '+ str(i))
    
    
while not que.empty():
    print(que.get())