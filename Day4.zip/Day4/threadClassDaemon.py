'''
	Inheriting the Thread Class
'''

import threading 
import time

def funAtWork():
    print(f'Work Started it will take 1 seconds')
    time.sleep(1)
    print(f'Work Completed..Fun Continues')


start = time.perf_counter()

t1 = threading.Thread(target=funAtWork,daemon=True)
t2 = threading.Thread(target=funAtWork,daemon=True)

t1.start()
t2.start()

t1.join()
t2.join()

end = time.perf_counter()
print(f'program finished in {round(end-start,3)} seconds')