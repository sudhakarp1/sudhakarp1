'''
'''

import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.connect((('192.168.1.4',9999)))
soc.send(b'Hai is this client..')
data = soc.recv(25)
print(data.decode('utf-8'))