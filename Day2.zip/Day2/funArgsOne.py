'''
Arguments in a function
'''

def funOne(*args, **kwargs):
    print(f'Args: {args}-->{kwargs}')
    
    

funOne(10, 20 ,1, a=1) #
funOne(x=10, y=20)
funOne(lst=[1,2,3,4,5,6])
funOne(b='')



