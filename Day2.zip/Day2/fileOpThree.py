'''
	first file Operation program to read a file and display its contents
'''

fileObj = open('fileOpThree.py','r')
for eachLine in fileObj:
    print(eachLine)
   
 