'''
	first file Operation program to read a file and display its contents
'''

with open('fileOpOne.py','r') as fileObj:
   contents = fileObj.read()
   print(contents)
 
 