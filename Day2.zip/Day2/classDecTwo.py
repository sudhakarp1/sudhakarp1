'''
	Implementing decorators using a class 
'''
class TimeCalculation:
	def __init__(self, Author, DoC):
		self.Author = Author
		self.DoC = DoC
		
	def __call__(self, fun):
		def wrapped(*args):        
			print(f'TimeKeeping started: By {self.Author} on {self.DoC}')
			fun(*args)
			print('TimeKeeping stopped: ')
			print('*' * 50)
		return wrapped

@TimeCalculation('Sachin','20-mar-2001')  
def preBuild(x, y): #decorated using buildProj
	print(f'Pre Build...{x} & {y}')

@TimeCalculation('Dravid','29-mar-2010')
def postBuild(): #decorated using buildProj
	print('Post Build...')

preBuild(10,20)
postBuild()
