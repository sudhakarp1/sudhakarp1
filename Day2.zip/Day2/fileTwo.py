'''
Introdution to pathlib
c:\\newfile.txt -->

 
'''

from pathlib import Path

var = Path(r'..')

for eachFile in var.iterdir():
    print(eachFile)
