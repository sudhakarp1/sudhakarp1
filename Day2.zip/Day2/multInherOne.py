'''
Multiple Inheritance
'''

class MyFileOp:
	def __init__(self, filename):
		print('myFileOp --> Opening...')
		
	def read(self):
		print('read line by line from the opened file')
		
	def write(self):
		print('writing into the given file')
class Network:
	def __init__(self):
		print('Network Initialized')
    
	def send(self, data=' '):
		print('sending data')    	
        
	def recieve(self):
		print('Recieve DAta')


class FileStream(MyFileOp, Network):
	def __init__(self):
		MyFileOp.__init__(self,'myfile')
		Network.__init__(self)

	def downLoad(self):
		self.recieve()
		self.write()
        
	def upLoad(self):
		self.read()
		self.send()
        
	
obj = FileStream()
obj.downLoad()
obj.upLoad()






