'''
	Inheritance from a existing class
'''

class myList(list):
	def append(self, obj):
		print('appending Here' , obj)
		super().append(obj)


lst = myList()

lst.append('Sachin')
lst.append('Virat')
lst.append('Rishab')

print(lst)
