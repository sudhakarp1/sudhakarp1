'''
Introdution to pathlib
c:\\newfile.txt -->

 
'''

from pathlib import Path

var = Path(r'..')

print(var)
if not var.exists():
    var.mkdir()
print(var.absolute())