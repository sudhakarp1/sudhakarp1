'''
	Inheritance from a existing class
'''

class myStr(str):
	def __str__(self):
		return "Mr. " + self
		

st = 'Sachin'
st1 = myStr("Tendulkar ")

print(f'st --> {st}')

print(f'st1 --> {st1}')
