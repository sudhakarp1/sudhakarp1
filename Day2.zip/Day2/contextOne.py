'''
	Context management
'''

class MyClass:
	def fun(self):
		print(f'MyClass fun')
		
	def __enter__(self):
		print('All Initialization are done here')
		return self
		
	def __exit__(self,a,b,c):#a-> exception_type, b->exception_value, c-> traceback
		print('Releasing all Resources')
		
with MyClass() as obj:
    print('Just Begining')
    obj.fun()
    print('Done with the function')



