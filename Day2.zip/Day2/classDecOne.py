'''
	Implementing decorators using a class 
'''

class TimeCalculation:
	def __init__(self, fn):
		self.fun = fn
		
	def __call__(self, *args):
		print('TimeKeeping started: ')
		self.fun(*args)
		print('TimeKeeping stopped: ')
		print('*' * 50)

@TimeCalculation  
def preBuild(x, y): #decorated using buildProj
	print(f'Pre Build...{x} & {y}')

@TimeCalculation
def postBuild(): #decorated using buildProj
	print('Post Build...')

preBuild(10,20)
#preBuild = TimeCalculation(preBuild)
#preBuild(10,20)

postBuild()
#postBuild = TimeCalculation(postBuild)
#postBuild(10,20)
