'''
	first file Operation program to read a file and display its contents
'''

with open('fileOpTwo.py','r') as fileObj:
    for eachLine in fileObj:
        print(eachLine)
   
 