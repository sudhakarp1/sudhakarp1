'''
	creating an abstract class in python.
'''
from abc import ABC, abstractmethod

class GameObject(ABC):
    @abstractmethod
    def Collide(self):
        pass
        
class SpaceShip(GameObject):
    def Collide(self):
        print('Space Ship collided...')
       
class Asteroid(GameObject):
    def Collide(self):
        print('Asteroid collided...')
        
def SpaceStationCollides(gObj):
    print('The station is damaged because')
    gObj.Collide()
    print('Have to rectify...')
    print('-' * 50)    
    
sp = SpaceShip()
ast = Asteroid()

SpaceStationCollides(sp)
SpaceStationCollides(ast)