'''
Introdution to pathlib
c:\\newfile.txt -->

'''

from pathlib import Path
import shutil

sourcePath = Path(r'..')
destPath = Path(r'c:\philips')

for eachFile in sourcePath.glob('*/*'):
    shutil.copy(eachFile, destPath)
    print(eachFile)
