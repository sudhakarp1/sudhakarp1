'''
	Defining Inheritance on user defined Class
'''
class MediaPlayer:
    def __init__(self):
        self.name = 'MX-Player'
        self.trackname = ''
        self.title = ''
        
    def play(self):
        print('MediaPlayer --> Play')
        
    def pause(self):
        print(f'MediaPlayer --> Pause {self.name}')
   
class AudioPlayer(MediaPlayer):
    def __init__(self):
        #super().__init__()
        self.name = 'MX-Player --> Audio Type'
    
    def play(self):
        print(f'AudioPlayer --> PLay {self.name}')
        
    def stop(self):
        print(f'AudioPlayer --> stop {self.name}')
     
ap = AudioPlayer()
ap.play()
ap.pause()
ap.stop()

print(isinstance(ap, AudioPlayer))
print(isinstance(ap, MediaPlayer))
print(isinstance(ap, object))

print(issubclass(AudioPlayer, MediaPlayer))
print(issubclass(AudioPlayer, object))