'''
	This is a demo for intro to Decorators
'''
#memoization in terms Data Structure

result = {0:0, 1:1}

def fibo(num):
    if num not in result:
        result[num] = fibo(num-1) + fibo(num-2)
    return result[num]
       

if __name__ == "__main__":
    import time
    start = time.time()
    for cnt in range(5000):
        print(cnt," --> ",fibo(cnt))
    
    end = time.time()
    print(f'Time taken is {end - start}')  