'''
	This is a demo for intro to Decorators
'''
from functools import lru_cache

@lru_cache # lru_cache is a decorator function from functools module
def fibo(num):
    if num<=1:
        return num
    
    return fibo(num-1) + fibo(num-2)
    


if __name__ == "__main__":
    import time
    start = time.time()
    for cnt in range(5000):
        print(cnt," --> ",fibo(cnt))
    
    end = time.time()
    print(f'Time taken is {end - start}')  