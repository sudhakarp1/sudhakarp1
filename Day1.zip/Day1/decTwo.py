'''
	This is a demo for intro to Decorators\
        This is nesting of functions
'''

def OuterFun():// Outer Function
    print('Outer Started')
    def InnerFun(): // Inner Function
        print('Inner')
        
    InnerFun()
    print('Outer Completed')
     
    
OuterFun()

