'''
	Simplest class in python
'''
class Simplest: #
  
    def __init__(self,var):
        self.data = var
        
    def printFun(self):
        print(f'Simplest ....{self.data}')    

    def __add__(self, other):
        return Simplest(self.data+other.data)
        
        
ob1 = Simplest(10)
ob2 = Simplest(20)

ob1.printFun() # printFun(ob1)

ob2.printFun() # printFun(ob2)

obj3 = ob1 + ob2
obj3.printFun()
