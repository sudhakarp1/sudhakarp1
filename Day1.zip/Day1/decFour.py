'''
	Step by step intro to Decorator Function is Python
'''

def buildProj(fn): #decorator 
    def wrapperFun():
        print('build started')
        fn()
        print('build completed')
        print('-' * 50)
    return wrapperFun
    
@buildProj    
def preBuild(): #decorated using buildProj
    print(f'Pre Build...')

@buildProj
def postBuild(): #decorated using buildProj
    print('Post Build...')

preBuild(10,20)
postBuild()
