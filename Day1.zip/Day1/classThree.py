'''
	Simplest class in python
    __name__ --> dunder name
    there are plenty of functions with the dunder ...
'''
class Simplest: #
    def __init__(self, var): # this works like a constructor
        self.data = var        
        
    def __str__(self):
        return f'Data Here ---> {self.data}'
        
    def printFun(self):
        print(f'Simplest ....{self.data} ')    

obj1 = Simplest(100) #__init__ is called 
print(obj1)
obj1.printFun()

obj2 = Simplest('Rishab') #__init__ is called
print(obj2)
obj2.printFun()