'''
	Step by step intro to Decorator Function is Python
'''
def buildProj(fn): #decorator 
    def wrapperFun(*args):
        print('build started')
        fn(*args)
        print('build completed')
        print('-' * 50)
    return wrapperFun
    
@buildProj   
def preBuild(x, y): #decorated using buildProj
    print(f'Pre Build...{x} {y}')

@buildProj
def postBuild(): #decorated using buildProj
    print('Post Build...')

preBuild(10,20)
postBuild()
