'''
	Step by step intro to Decorator Function is Python
'''
def buildProj(fn):
    def wrapperFun():
        print('build started')
        fn() # is open to changes/ 
        print('build completed')
        print('-' * 50)
    return wrapperFun
    
def preBuild():
    print('Pre Build...')

def postBuild():
    print('Post Build...')

preBuild = buildProj(preBuild)
postBuild = buildProj(postBuild)

preBuild()
postBuild()
