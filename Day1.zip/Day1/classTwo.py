'''
	Simplest class in python
'''
class Simplest: #
    myData = 'Simplest Data'    
    def setData(self,var): # setter method
        self.data = var
    def getData(self): #getter method
        return self.data 
    
    def printFun(self):
        print(f'Simplest ....{self.data} {self.myData}')    

ob1 = Simplest()
ob2 = Simplest()

print(ob1)
ob1.setData(20) #setData(ob1,20)
ob1.printFun() # printFun(ob1)

print(ob2)
ob2.setData(30) #setData(ob2,20)
ob2.printFun() # printFun(ob2)
