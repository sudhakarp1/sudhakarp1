'''
	Simplest class in python
'''

class Simplest:
	pass	

ob1 = Simplest()

print(ob1)