'''
	Step by step intro to Decorator Function is Python
'''

def OuterFun(fn): # Wrapper function // Outer function
    print('Outer function started')
    fn() # wrapped function 
    print('Outer function Completed')
       
def functionToTest():
    print('functionToTest')
   
OuterFun(functionToTest)
